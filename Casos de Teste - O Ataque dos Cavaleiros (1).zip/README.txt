Arquivo zip gerado em: 02/11/2017 13:04:57 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: O Ataque dos Cavaleiros